'use strict';

var app = angular.module('StudyRoom', []);
app.controller('bookingWindowController',
    function ($scope, $http) {

        $scope.tabName = "AC";
        $scope.CurrentDate = new Date();
        $scope.style = function (value) {
            return { "width": "45%" };
        };

        $http.get('../../public_html/HTML/JSON/Batch.json').success(function (data) {
            $scope.batchinformation = data;
        });

        $scope.batchTitle = "Select Batch";
        $scope.price = 0;
        var duration = 0;
        $scope.Discount = 0;
        $scope.discpercentage = 0;
        $scope.startdate = new Date();
        $scope.duration = 0;
        $scope.isbatchSelected = false;
        $scope.batchtotal = 0;
        $scope.updateBatchInfo = function (batch) {
            $scope.batchTitle = batch.title;
            $scope.price = batch.price;
            $scope.isDiscApp = batch.isDiscApp;
            $scope.discpercentage = batch.discount;
            duration = batch.validity;
            $scope.duration = duration;
            $scope.update_endDate($scope.startdate);
            $scope.isbatchSelected = true;
            $scope.batchtotal = $scope.calculateBatchTotal();
        };
        $scope.reset_batchinfo = function () {
            $scope.batchTitle = "Select Batch";
            $scope.price = 0;
            $scope.Discount = 0;
            $scope.startdate = new Date();
            $scope.duration = 0;
            $scope.isbatchSelected = false;
            $scope.batchtotal = 0;
            $scope.discpercentage = 0;
        };
        $scope.update_endDate = function (startdate) {
            $scope.startdate = startdate;
            var enddate = moment(startdate);
            enddate.add(duration, 'days');
            $scope.enddate = enddate.toDate();
        };
        $scope.calculateBatchTotal = function () {
            var total = 0;
            var total1 = $scope.price;
            if ($scope.isDiscApp) {
                total = total1 * (100 - $scope.discpercentage) / 100;
                $scope.Discount = total1 - total;
            }
            else{
                total = total1;
            }
            return total;
        };

        var isactive = false;
        $scope.OpenCollapse = function () {
            if (!isactive) {
                isactive = true;
                $scope.style2 = function (value) {
                    return { "display": "block" }
                }

            }
            else {
                isactive = false;
                $scope.style2 = function (value) {
                    return { "display": "none" }
                }

            }
        }
        var isAONactive = false;
        $scope.OpenAddonCollapse = function () {
            if (!isAONactive) {
                isAONactive = true;
                $scope.style3 = function (value) {
                    return { "display": "block" }
                }

            }
            else {
                isAONactive = false;
                $scope.style3 = function (value) {
                    return { "display": "none" }
                }

            }
        }
        $scope.calculateEndDate = function (startdate, duration) {
            var enddate = moment(startdate);
            enddate.add(duration, 'days');
            return enddate.toDate();
        }


        $scope.isRSActive = false;
        var RSprice = 0;
        var RSDuration = 0;
        $scope.reserved_seat_startdate = $scope.startdate

        $scope.reservedseat = function (reserved_seat) {
            RSprice = reserved_seat.value;
            RSDuration = reserved_seat.key;
            $scope.isRSActive = true;
            $scope.reserved_seat_enddate = $scope.calculateEndDate($scope.reserved_seat_startdate, RSDuration);
            $scope.rsTitle = reserved_seat.title;
            $scope.rsduration = RSDuration;
            $scope.rsprice = RSprice;
        }

        $scope.reset_reservedseat = function () {
            $scope.isRSActive = false;
            RSprice = 0;
            RSDuration = 0;
            $scope.rsprice = 0;
            $scope.reserved_seat_startdate = $scope.startdate
        }

        $scope.update_RS_endDate = function (startdate) {
            $scope.reserved_seat_startdate = startdate;
            $scope.reserved_seat_enddate = $scope.calculateEndDate(startdate, RSDuration);
        };


        $scope.isLockerActive = false;
        var lockerprice = 0;
        var lockerDuration = 0;
        $scope.locker_startdate = $scope.startdate;
        $scope.updatelocker = function (locker) {
            lockerprice = locker.value;
            lockerDuration = locker.key;
            $scope.isLockerActive = true;
            $scope.lockerTitle = locker.title;
            $scope.lockerduration = lockerDuration;
            $scope.lockerprice = lockerprice;
            $scope.locker_enddate = $scope.calculateEndDate($scope.locker_startdate, lockerDuration);
        }

        $scope.reset_locker = function () {
            $scope.isLockerActive = false;
            lockerprice = 0;
            lockerDuration = 0;
            $scope.lockerprice = 0;
            $scope.locker_startdate = $scope.startdate;
        }

        $scope.update_locker_endDate = function (startdate) {
            $scope.locker_startdate = startdate;
            $scope.locker_enddate = $scope.calculateEndDate(startdate, lockerDuration);
        };
        $scope.isSEactive = false;
        var product_dict = [];
        $scope.study_essen_total = 0;
        $scope.update_study_essentials = function (product) {
            var index = product_dict.indexOf(product);
            var add = 0;
            var sub = 0;
            if (index < 0) {

                product_dict.push(product);
                add = product.price;
            } else {
                product_dict.splice(index, 1);
                sub = product.price;
            }
            if (product_dict) {
                $scope.isSEactive = false;
            }
            else {
                $scope.isSEactive = true;
            }
            $scope.study_essen_total = $scope.study_essen_total + add - sub;
        }
        $scope.se_products = product_dict;

        var other_product_dict = [];
        $scope.othertotal = 0;
        $scope.update_other = function (product) {
            var index = other_product_dict.indexOf(product);
            var add = 0;
            var sub = 0;
            if (index < 0) {
                other_product_dict.push(product);
                add = product.price;
            } else {
                other_product_dict.splice(index, 1);
                sub = product.price;
            }
            $scope.othertotal = $scope.othertotal + add - sub;
        }
        $scope.otherproducts = other_product_dict;

        $scope.calculateTotal = function () {
            var total = 0;
            var batchtotal = $scope.batchtotal();
            total = batchtotal + $scope.othertotal + $scope.study_essen_total + $scope.lockerprice + $scope.rsprice;
            return total;
        }


    });