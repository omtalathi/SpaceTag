'use strict';
var module = angular.module('StudyRoom', []);
module.controller('bookingWindowController', function ($scope) {

});

var app = angular.module('StudyRoom', []);
app.controller('bookingWindowController',
    function ($scope, $http) {
        $scope.tabName = "AC";
        $scope.CurrentDate = new Date();
        $scope.style = function (value) {
            return { "width": "50%" };
        };

        $http.get('../../public_html/HTML/JSON/Batch.json').success(function (data) {
            $scope.batchinformation = data;
        });

        $scope.batchTitle = "Select Batch";
        $scope.price = 0;
        $scope.duration = 3;
        $scope.Discount = 0;
        $scope.Total = 0;
        $scope.AonTitle = "Null";
        $scope.AonPrice = 0;

        $scope.updateBatchInfo = function (batch) {
            $scope.batchTitle = batch.title;
            $scope.price = batch.price;
            $scope.isDiscApp = batch.isDiscApp;
            $scope.Discount = batch.discount;
        };

        $scope.updateAddOns = function (AddOn) {
            $scope.AonTitle = AddOn.title;
            $scope.AonPrice = AddOn.price * $scope.duration;
        };
        $scope.Total = function () {
            var total1 = $scope.price * $scope.duration;
            if ($scope.isDiscApp) {
                total1 = total1 * (100 - $scope.Discount) / 100;
            }
            var total = total1 + $scope.AonPrice ;
            return total;
        };

    });