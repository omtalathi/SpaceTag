
'use strict';

var module = angular.module('StudyRoom', []);
module.controller('StudyRoomController', function ($scope, $http) {
    $scope.tabName = "AC";
    $scope.CurrentDate = new Date();
    $scope.ClickToUnlock = true;
    $scope.style = function (value) {
        return { "width": "35%" };
    };
    $scope.$watch('ClickToUnlock', function () {
        $scope.phoneNumber = $scope.ClickToUnlock ? '9822XXX450' : '9822123450';
    });
    $scope.$
    $http.get('JSON/studyRoom.json').success(function (data) {
        $scope.studyRoom = data;
    });
    $scope.isButtonVisible = false;
    $scope.AC = true;
    $scope.NAC = false;
    $scope.hideButton = function () {
        $scope.isButtonVisible = false;
        $scope.tabName = "AON";
        $scope.AC = false;
        $scope.NAC = false;
        $scope.AON = true;
        
    };
    $scope.showButton = function () {
        $scope.isButtonVisible = true;
        $scope.AC = true;
        $scope.tabName = "AC";
        $scope.AON = false;
        $scope.NAC = false;
    };

    $scope.ACTab = function(){
        $scope.AC = true;
        $scope.tabName = "AC";
        $scope.AON = false;
        $scope.NAC = false;
    }
    $scope.NACTab = function(){
        $scope.tabName = "NAC";
        $scope.NAC = true;
        $scope.AC = false;
        $scope.AON = false;
    }

    $scope.fontcolor = function (value) {
        return { "color": "red" };
    }



});