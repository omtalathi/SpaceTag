'use strict';

var app = angular.module('StudyRoom', []);
app.controller('bookingWindowController',
    function ($scope, $http) {
        $scope.tabName = "AC";
        $scope.CurrentDate = new Date();
        $scope.style = function (value) {
            return { "width": "50%" };
        };

        $http.get('../../public_html/HTML/JSON/Batch.json').success(function (data) {
            $scope.batchinformation = data;
        });

        $scope.batchTitle = "Select Batch";
        $scope.price = 0;
        $scope.duration = 3;
        $scope.Discount = 0;
        $scope.Total = 0;
        $scope.AonTitle = "Null";
        $scope.AonPrice = 0;
        $scope.disc = 0;

        $scope.updateBatchInfo = function (batch) {
            $scope.batchTitle = batch.title;
            $scope.price = batch.price;
            $scope.isDiscApp = batch.isDiscApp;
            $scope.disc = batch.discount;
        };
       
        $scope.updateDuration = function(duration){
            $scope.duration = duration;
        };

        $scope.updateAddOns = function (AddOn) {
            $scope.AonTitle = AddOn.title;
            $scope.AonPrice = AddOn.price * $scope.duration;
        };
        $scope.Total = function () {
            var total;
            var total1 = $scope.price * $scope.duration;
            if ($scope.isDiscApp) {
                total = total1 * (100 - $scope.disc) / 100;
                $scope.Discount = total1-total;
            }
            var total = total + $scope.AonPrice ;
            return total;
        };

    });